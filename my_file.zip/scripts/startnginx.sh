#!/bin/bash
systemctl start nginx